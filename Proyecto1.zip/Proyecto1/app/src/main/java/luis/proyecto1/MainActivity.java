package luis.proyecto1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> tareas;
    private ArrayAdapter<String> tareasTemp;
    private ListView listaTareas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaTareas = (ListView) findViewById(R.id.listaTareas);
        tareas = new ArrayList<String>();
        tareasTemp = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, tareas);
        listaTareas.setAdapter(tareasTemp);
        tareas.add("SOY TAREA 1111111");
        setupListViewListener();
    }

    private void setupListViewListener() {
        listaTareas.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> adapter, View item, int pos, long id) {
                        tareas.remove(pos);
                        tareasTemp.notifyDataSetChanged();
                        return true;
                    }
                });
    }

    public void agregarTarea(View v) {
        EditText editarTarea = (EditText) findViewById(R.id.editarTarea);
        String itemText = editarTarea.getText().toString();
        tareasTemp.add(itemText);
        editarTarea.setText("");
    }

    public void eliminarTarea(View v) {
        tareas.remove(tareas.size()-1);
        tareasTemp.notifyDataSetChanged();
    }
}
